﻿using System;
using System.Text;

namespace ConsoleApp
{
	class Program
	{
		static WeakReference weak;
		static void Main()
		{
			InitWR();
			ShowTarget(); // Выводит weak
			GC.Collect();
			ShowTarget(); // Выводит null
		}
		static void InitWR()
		{
			weak = new WeakReference(new StringBuilder("week"));
		}
		static void ShowTarget()
		{
			if (weak.Target != null) Console.WriteLine(weak.Target.ToString());
			else Console.WriteLine("null");
		}
	}
}
