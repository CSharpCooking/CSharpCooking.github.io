﻿using System;
using System.Text;

namespace ConsoleApp
{
	class Program
	{
		static void Main()
		{
			var sb = new StringBuilder("this is a test");
			var weak = new WeakReference(sb);
			// GC.Collect();
			Console.WriteLine(weak.Target.ToString()); // Выводит this is a test
		}
	}
}
