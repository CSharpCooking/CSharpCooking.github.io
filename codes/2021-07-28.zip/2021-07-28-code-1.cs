class Host
{
	public event EventHandler Click;
}
class Client
{
	Host _host;
	public Client(Host host)
	{
		_host = host;
		_host.Click += HostClicked;
	}
	void HostClicked(object sender, EventArgs e) { ... }
}

class Test
{
	static Host _host = new Host();
	public static void CreateClients()
	{
		Client[] clients = Enumerable.Range(0, 1000)
		.Select(i => new Client(_host))
		.ToArray();
		// Делать что-нибудь с экземплярами класса Client ...
	}
}

public void Dispose() { _host.Click -= HostClicked; }

Array.ForEach (clients, с => с.Dispose ());