<Query Kind="Statements" />

string r =
  @"<(?'tag'\w+?).*>" +    // match first tag, and name it 'tag'
  @"(?'text'.*?)" +        // match text content, name it 'text'
  @"</\k'tag'>";           // match last tag, denoted by 'tag'

string text = "<h1>hello</h1>";

Match m = Regex.Match(text, r);

Console.WriteLine(m.Groups["tag"].Value); // h1
Console.WriteLine(m.Groups["text"].Value); // hello

// --------------------------------------

Console.WriteLine();

string html = "<i>By default</i> quantifiers are <i>greedy</i> creatures";

foreach (Match m1 in Regex.Matches(html, @"<i>.*</i>"))
	Console.WriteLine(m1.Value);

Console.WriteLine();

foreach (Match m2 in Regex.Matches(html, @"<i>.*?</i>"))
	Console.WriteLine(m2.Value);