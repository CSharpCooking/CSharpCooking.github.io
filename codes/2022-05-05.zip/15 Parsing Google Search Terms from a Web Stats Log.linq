<Query Kind="Statements" />

string sample = "http://www.google.com/search?hl=en&q=greedy+quantifiers+regex&btnG=Search";

Match m = Regex.Match(sample, @"(?<=google\..+search\?.*q=).+?(?=(&|$))");

string[] keywords = m.Value.Split(new[] { '+' }, StringSplitOptions.RemoveEmptyEntries);

foreach (var keyword in keywords)
	Console.Write(keyword + " "); // greedy quantifiers regex