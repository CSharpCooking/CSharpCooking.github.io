﻿using System;
using System.Threading;
using System.Diagnostics;

namespace CSharpCooking
{
  class Program
  {
    static void CreateCookedProgramsCounter()
    {
      string category = "CSharpCooking";
      string categoryDescription = "CSharpCooking Monitoring";
      string counter1 = "Delicious programs";
      string counterDescription1 = "Number of delicious programs";
      string counter2 = "Bad programs";
      string counterDescription2 = "Number of bad programs";
      if (!PerformanceCounterCategory.Exists(category))
      {
        CounterCreationDataCollection cd = new CounterCreationDataCollection();
        cd.Add(new CounterCreationData(counter1, counterDescription1,
          PerformanceCounterType.NumberOfItems32));
        cd.Add(new CounterCreationData(counter2, counterDescription2,
          PerformanceCounterType.NumberOfItems32));
        PerformanceCounterCategory.Create(category, categoryDescription,
          PerformanceCounterCategoryType.SingleInstance, cd);
      }
    }
    static void WriteCookedProgramsCounter(string category, string counter,
                         int frequency, EventWaitHandle stopper)
    {
      using (PerformanceCounter pc = new PerformanceCounter(category, counter, ""))
      {
        pc.ReadOnly = false;
        pc.RawValue = 0;
        pc.Increment();
        while (!stopper.WaitOne(1000 / frequency))
        {
          pc.Increment(); // or pc.IncrementBy(1);
        }
      }
    }
    static void DeleteCookedProgramsCounter()
    {
      string category = "CSharpCooking";
      if (PerformanceCounterCategory.Exists(category))
        PerformanceCounterCategory.Delete(category);
    }
    static void Main()
    {
      CreateCookedProgramsCounter();
      EventWaitHandle stopper = new ManualResetEvent(false);
      new Thread(() => WriteCookedProgramsCounter("CSharpCooking",
        "Delicious programs", 10, stopper)).Start();
      new Thread(() => WriteCookedProgramsCounter("CSharpCooking",
        "Bad programs", 2, stopper)).Start();
      Console.ReadKey();
      stopper.Set();
      // DeleteCookedProgramsCounter();
    }
  }
}