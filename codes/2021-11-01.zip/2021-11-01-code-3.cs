﻿using System;
using System.Diagnostics;
using System.Threading;

namespace CSharpCooking
{
  class Program
  {
    static void Monitor(string category, string counter,
              string instance, EventWaitHandle stopper)
    {
      if (!PerformanceCounterCategory.Exists(category))
        throw new InvalidOperationException("Category does not exist");
      if (!PerformanceCounterCategory.CounterExists(counter, category))
        throw new InvalidOperationException("Counter does not exist");
      if (instance == null) instance = ""; //"" == экземпляры отсутствуют (не null!)
      if (instance != "" &&
      !PerformanceCounterCategory.InstanceExists(instance, category))
        throw new InvalidOperationException("Instance does not exist");
      float lastValue = 0f;
      using (PerformanceCounter pc =
           new PerformanceCounter(category, counter, instance))
      {
        while (!stopper.WaitOne(200))
        {
          float value = pc.NextValue();
          if (value != lastValue) // Записывать значение, только
          {             // если оно изменилось.
            Console.WriteLine($"{category}|{counter}|{instance} = {value}");
            lastValue = value;
          }
        }
      }
    }
    static void Main()
    {
      EventWaitHandle stopper = new ManualResetEvent(false);
      new Thread(() => Monitor("Processor", "% Processor Time",
                   "_Total", stopper)).Start();
      new Thread(() => Monitor("LogicalDisk", "% Idle Time",
                   "C:", stopper)).Start();
      Console.WriteLine("Monitoring - press any key to quit");
      Console.ReadKey();
      stopper.Set();
    }
  }
}