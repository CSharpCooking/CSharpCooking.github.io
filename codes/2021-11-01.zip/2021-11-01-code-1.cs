﻿using System;
using System.Diagnostics;

namespace CSharpCooking
{
  class Program
  {
    static void Main()
    {
      PerformanceCounterCategory[] cats =
        PerformanceCounterCategory.GetCategories();
      foreach (PerformanceCounterCategory cat in cats)
      {
        Console.WriteLine("Category: " + cat.CategoryName); // Категория
        string[] instances = cat.GetInstanceNames();
        if (instances.Length == 0)
        {
          foreach (PerformanceCounter ctr in cat.GetCounters())
            Console.WriteLine(" Counter: " + ctr.CounterName); // Счетчик
        }
        else // Вывести счетчики, имеющие экземпляры
        {
          foreach (string instance in instances)
          {
            Console.WriteLine(" Instance: " + instance); // Экземпляр
            if (cat.InstanceExists(instance))
              foreach (PerformanceCounter ctr in cat.GetCounters(instance))
                Console.WriteLine(" Counter: " + ctr.CounterName); // Счетчик
          }
        }
      }
    }
  }
}