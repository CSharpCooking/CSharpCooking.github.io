﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CellModel
{
	public partial class MainForm : Form
	{
		private sealed class Cell
		{
			/// <summary>
			/// Клеточное поле
			/// </summary>
			private readonly List<Cell> cells;
			/// <summary>
			/// Клетки-соседи (от 3 до 8)
			/// </summary>
			private Cell[] neighbours;

			/// <summary>
			/// Местоположение и размер клетки
			/// </summary>
			private readonly Rectangle cell;
			/// <summary>
			/// Цвет клетки
			/// </summary>
			private readonly Brush color;
			/// <summary>
			/// Текущее состояние клетки
			/// </summary>
			private (bool value, bool? buffer) isDie;
			public Cell(Rectangle cell, List<Cell> cells, bool isDie, Brush color = null)
			{
				this.cell = cell;
				this.cells = cells;
				this.color = color ?? Brushes.Red;
				this.isDie = (isDie, null);
			}
			/// <summary>
			/// Отрисовка клетки
			/// </summary>
			public void Draw(Graphics context)
			{
				if (isDie.value)
				{
					context.DrawRectangle(Pens.Black, cell);
				}
				else
				{
					context.FillRectangle(color, cell);
				}
			}
			/// <summary>
			/// Актуализирует состояние клетки из буфера
			/// </summary>
			public void Flush()
			{
				isDie.value = isDie.buffer.Value;
				isDie.buffer = null;
			}
			/// <summary>
			/// Формирование ссылок на соседей клетки
			/// </summary>
			public void SetNeighbours()
			{
				neighbours = cells.Where(c =>
					{
						if (this == c)
						{
							return false;
						}

						int cellSize = cell.Size.Width;

						return Math.Abs(cell.Left - c.cell.Left) <= cellSize && Math.Abs(cell.Top - c.cell.Top) <= cellSize;
					})
					.ToArray();
			}
			/// <summary>
			/// Расчет текущего состояния клетки
			/// </summary>
			public void CalculateState()
			{
				int livingCellCount = 0;
				foreach (Cell cell in neighbours)
				{
					if (!cell.isDie.value)
					{
						livingCellCount++;
					}
				}
				// Запись состояния клетки через буфер
				switch (livingCellCount)
				{
					// Если потенциал клетки равен двум, то клетка сохраняет свое состояние
					case 2:
						isDie.buffer = isDie.value;
						return;
					// Если потенциал равен трем, то клетка оживает
					case 3:
						isDie.buffer = false;
						return;
					// Если потенциал меньше двух или больше трех, то клетка погибает
					default:
						isDie.buffer = true;
						return;
				}
			}
			public override string ToString() => cell.ToString();
		}
		/// <summary>
		/// Поверхность для рисования
		/// </summary>
		/// 
		private readonly Graphics graphic;
		/// <summary>
		/// Токен отмены расчетов
		/// </summary>
		private readonly CancellationTokenSource token;
		/// <summary>
		/// Клеточное поле
		/// </summary>
		private readonly List<Cell> cells;
		/// <summary>
		/// Задачи для обработки клеточного поля
		/// </summary>
		private readonly Action[] tasks;
		protected override CreateParams CreateParams
		{
			get
			{
				CreateParams CP = base.CreateParams;
				CP.ExStyle = CP.ExStyle | 0x2000000; // WS_EX_COMPOSITED
				return CP;
			}
		}
		public MainForm()
		{
			InitializeComponent();
			// Размер каждой клетки
			int cellSize = int.Parse(ConfigurationManager.AppSettings["CellSize"]);
			// Количество клеток по X и Y
			string[] xyCellsCount = ConfigurationManager.AppSettings["XYCellsCount"].Split(';');
			Size cellsCount = new Size
			{
				Width = int.Parse(xyCellsCount[0]),
				Height = int.Parse(xyCellsCount[1])
			};
			// Меняем размер формы
			ClientSize = new Size(cellsCount.Width * cellSize, cellsCount.Height * cellSize);
			OnResize(null);
			graphic = CreateGraphics();
			Rectangle clip = new Rectangle(0, 0, ClientSize.Width, ClientSize.Height);
			graphic.SetClip(clip);
			token = new CancellationTokenSource();
			cells = new List<Cell>(cellsCount.Width * cellsCount.Height);
			tasks = new Action[int.Parse(ConfigurationManager.AppSettings["YTaskCount"])];
			Random random = new Random();
			Point currentCell = Point.Empty;
			double count = cells.Capacity / (double)tasks.Length;
			for (int i = 0; i < tasks.Length; i++)
			{
				int startIndex = (int)Math.Round(count * i);
				int finalIndex = (int)Math.Round(count * (i + 1));
				for (int c = startIndex; c < finalIndex; c++)
				{
					// Определяем позицию клетки и случайно задаем состояние
					Rectangle rect = new Rectangle
					(
						new Point(currentCell.X * cellSize, currentCell.Y * cellSize),
						new Size(cellSize, cellSize)
					);
					Cell cell = new Cell(rect, cells, Convert.ToBoolean(random.Next(0, 2)));
					cells.Add(cell);

					// Переход на следующую клетку
					currentCell.X += 1;
					if (currentCell.X >= cellsCount.Width)
					{
						currentCell.X = 0;
						currentCell.Y += 1;
					}
				}
				// Сохраняем функции для последующего выполнения
				tasks[i] = () =>
				{
					for (int c = startIndex; c < finalIndex; c++)
					{
						cells[c].CalculateState();
					}
				};
			}
			Parallel.ForEach(cells,c => c.SetNeighbours());
		}

		/// <summary>
		/// Отрисовка области
		/// </summary>
		protected override void OnPaint(PaintEventArgs e)
		{
			if (!token.IsCancellationRequested)
			{
				foreach (Cell cell in cells)
					cell.Draw(graphic);
				updateTimer.Start();
			}
		}
		/// <summary>
		/// Метод, выполняющий расчеты и вызывающий перерисовку области по таймеру
		/// </summary>
		private void UpdateTimer_Tick(object sender, EventArgs e)
		{
			updateTimer.Stop();
			if (!token.IsCancellationRequested)
			{
				// Запуск расчетов, хранение состояния клеток в буфере
				Parallel.Invoke(tasks);
				// Извлечение состояния клеток из буфера
				Parallel.ForEach(cells, c => c.Flush());
				// Вызов прорисовки
				Invalidate();
			}
		}
		/// <summary>
		/// Обработка нажатия клавиш
		/// </summary>
		private void MainForm_KeyUp(object sender, KeyEventArgs e)
		{
			// Останавливаем расчеты
			if (e.KeyCode == Keys.S)
			{
				token.Cancel();
			}
		}
	}
}
