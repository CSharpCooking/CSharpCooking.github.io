class A
{
	Expensive _expensive;
	public Expensive Expensive
	{
		get
		{
			LazyInitializer.EnsureInitialized
				(ref _expensive, () => new Expensive());
			return _expensive;
		}
	}
}

class Expensive { }