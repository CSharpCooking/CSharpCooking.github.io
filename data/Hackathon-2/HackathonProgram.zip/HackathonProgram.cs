using BitVectorLib;
using System.Security.Cryptography;
using System.Text;
using System.Collections.Concurrent;
using System.Threading.Tasks;

// ============================================================
// Метод получения 10 эталонов
// ============================================================
static string[] GetDefaultEtalons10() =>
new[]
{
    new string("111111111111111111111111111111111111111111111111111111000000000000000000000000".Reverse().ToArray()),
    new string("000000000100000000000000000111111111111111111100000000000000000000000011111111".Reverse().ToArray()),
    new string("100000000000000000111111111111111111100000000111111111111111110000000000000000".Reverse().ToArray()),
    new string("100000000100000000111111111100000000100000000000000000111111111111111111111111".Reverse().ToArray()),
    new string("000000000111111111100000000111111111111111111100000000000000001111111100000000".Reverse().ToArray()),
    new string("100000000111111111111111111100000000111111111111111111000000001111111100000000".Reverse().ToArray()),
    new string("111111111100000000000000000100000000111111111111111111000000001111111111111111".Reverse().ToArray()),
    new string("111111111100000000111111111100000000000000000000000000000000000000000011111111".Reverse().ToArray()),
    new string("111111111111111111111111111111111111111111111111111111000000001111111100000000".Reverse().ToArray()),
    new string("100000000111111111111111111111111111100000000000000000111111111111111100000000".Reverse().ToArray()),
};

// ============================================================
// Выбор случайного фрагмента из книги
// ============================================================
static string PickRandomFragment(string bookPath, int charLength)
{
    string text = File.ReadAllText(bookPath, Encoding.UTF8);

    if (text.Length < charLength)
        throw new InvalidOperationException("Размер книги меньше запрашиваемого фрагмента.");

    int maxStart = text.Length - charLength;
    int start = RandomNumberGenerator.GetInt32(maxStart + 1);

    return text.Substring(start, charLength);
}


// ============================================================
// Шифрование фрагмента и сохранение в файл
// ============================================================
static void EncryptFragmentToFile(string outputPath, byte[] data, AssocStego stego)
{
    using FileStream fs = new FileStream(outputPath, FileMode.Create, FileAccess.Write);
    using AssocStegoStream s = new AssocStegoStream(fs, stego);

    s.Write(data, 0, data.Length);
}

// ============================================================
// Расшифрование фрагмента из файла
// ============================================================
static byte[] DecryptFragmentBytesFromFile(string pathStego, int expectedByteLength, AssocStego stego)
{
	byte[] result = new byte[expectedByteLength];

	using FileStream fs = new FileStream(pathStego, FileMode.Open, FileAccess.Read);
	using AssocStegoStream s = new AssocStegoStream(fs, stego);

	int total = 0;
	while (total < expectedByteLength)
	{
		int r = s.Read(result, total, expectedByteLength - total);
		if (r == 0)
			break; // конец стегопотока
		total += r;
	}

	if (total < expectedByteLength)
	{
		Console.WriteLine($"Предупреждение: прочитано {total} байт из ожидаемых {expectedByteLength}");
		Array.Resize(ref result, total);
	}

	return result;
}

// ============================================================
// Проверка равенства фрагментов
// ============================================================
static bool VerifyFragments(byte[] original, byte[] decrypted)
{
    if (original == null || decrypted == null)
        return false;

    if (original.Length != decrypted.Length)
        return false;

    for (int i = 0; i < original.Length; i++)
        if (original[i] != decrypted[i])
            return false;

    return true;
}

// 1. Эталоны
string[] etalons = GetDefaultEtalons10();

// 2. Пути
// string bookPath = @"/home/kai-cs/Hackathon/Selyankin_Kogda-truba-zovet.txt";
// string pathKey = @"/home/kai-cs/Hackathon/stego_key.bin";
// string pathStego = @"/home/kai-cs/Hackathon/stego_data.bin";
// string pathPlainFragment = @"/home/kai-cs/Hackathon/fragment_plain.txt";
// string pathDecryptedFragment = @"/home/kai-cs/Hackathon/fragment_decrypted.txt";

string bookPath = @"c:\Users\landw\Downloads\Selyankin_Kogda-truba-zovet.txt";
string pathKey = @"c:\Users\landw\Downloads\stego_key.bin";
string pathStego = @"c:\Users\landw\Downloads\stego_data.bin";
string pathPlainFragment = @"c:\Users\landw\Downloads\fragment_plain.txt";
string pathDecryptedFragment = @"c:\Users\landw\Downloads\fragment_decrypted.txt";

// 3. Стего-алгоритм и ключ
var aStego = new AssocStego(etalons);
var key = aStego.CreateKey();
aStego.SaveKeyToFile(pathKey, key);

// 4. Случайный фрагмент из книги (в символах)
string fragment = PickRandomFragment(bookPath, 1000);
File.WriteAllText(pathPlainFragment, fragment, Encoding.UTF8);

// Байтовое представление (то, что реально шифруем)
byte[] fragmentBytes = Encoding.UTF8.GetBytes(fragment);

// 5. Шифруем байты фрагмента
EncryptFragmentToFile(pathStego, fragmentBytes, aStego);

// 6. Восстанавливаем алгоритм и ключ
var aStego2 = new AssocStego(etalons);
aStego2.LoadKeyFromFile(pathKey);

// 7. Дешифруем из файла (по количеству БАЙТ, а не символов)
byte[] decryptedBytes = DecryptFragmentBytesFromFile(pathStego, fragmentBytes.Length, aStego2);
string decryptedFragment = Encoding.UTF8.GetString(decryptedBytes);

File.WriteAllText(pathDecryptedFragment, decryptedFragment, Encoding.UTF8);

// 8. Верификация
bool ok = VerifyFragments(fragmentBytes, decryptedBytes);

Console.WriteLine(ok
    ? "Исходный и расшифрованный фрагменты совпадают."
    : "Исходный и расшифрованный фрагменты не совпадают.");

// ============================================================
// Поток-обёртка, осуществляющий стего-кодирование/декодирование
// ============================================================
public class AssocStegoStream : Stream
{
    private readonly Stream _stream;
    private readonly AssocStego _stegoAlg;

    // Длина одного контейнера в байтах (по числу бит эталона)
    private readonly int _containerByteLen;
    // Длина стего-блока, соответствующего одному скрытому байту
    // (для 10-эталонного кодирования: 3 контейнера по одному на каждую десятичную цифру)
    private readonly int _hiddenByteLen;

    public AssocStegoStream(Stream stream, AssocStego stegoAlg)
    {
        _stream = stream ?? throw new ArgumentNullException(nameof(stream));
        _stegoAlg = stegoAlg ?? throw new ArgumentNullException(nameof(stegoAlg));

        _containerByteLen = (_stegoAlg.etalonLength + 7) >> 3;
        _hiddenByteLen = 3 * _containerByteLen; // т.к. кодируем байт тремя цифрами (0..9)
    }

    public override bool CanRead => _stream.CanRead;
    public override bool CanSeek => false;
    public override bool CanWrite => _stream.CanWrite;

    public override long Length => _stream.Length;

    public override long Position
    {
        get => _stream.Position;
        set => throw new NotSupportedException("Перемотка в стего-потоке не поддерживается.");
    }

    public override void Flush() => _stream.Flush();

    // --------------------------------------------------------
    // WRITE: скрытие байтов (каждый байт -> 3 контейнера)
    // --------------------------------------------------------
    public override void Write(byte[] buffer, int offset, int count)
    {
        if (buffer == null)
            throw new ArgumentNullException(nameof(buffer));
        if (offset < 0 || count < 0 || offset + count > buffer.Length)
            throw new ArgumentOutOfRangeException(nameof(offset));

        for (int i = offset; i < offset + count; i++)
        {
            byte b = buffer[i];
            byte[] hidden = HideByte(b);                // превращаем 1 байт в 3 контейнера
            _stream.Write(hidden, 0, hidden.Length);    // пишем в подложенный поток
        }
    }

    // --------------------------------------------------------
    // READ: раскрытие байтов (3 контейнера -> 1 байт)
    // --------------------------------------------------------
    public override int Read(byte[] buffer, int offset, int count)
    {
        if (buffer == null)
            throw new ArgumentNullException(nameof(buffer));
        if (offset < 0 || count < 0 || offset + count > buffer.Length)
            throw new ArgumentOutOfRangeException(nameof(offset));
        if (!_stream.CanRead)
            throw new NotSupportedException("Подлежащий поток не поддерживает чтение.");

        int readCount = 0;

        for (int i = offset; i < offset + count; i++)
        {
            var hidden = new byte[_hiddenByteLen];
            int totalRead = 0;

            // читаем стего-блок, соответствующий одному байту
            while (totalRead < _hiddenByteLen)
            {
                int r = _stream.Read(hidden, totalRead, _hiddenByteLen - totalRead);
                if (r == 0)
                    return readCount;   // достигнут конец потока

                totalRead += r;
            }

            // декодируем скрытый байт
            buffer[i] = DiscloseByte(hidden);
            readCount++;
        }

        return readCount;
    }

    // Эти операции не поддерживаются (позиционирование/изменение длины)
    public override long Seek(long offset, SeekOrigin origin)
        => throw new NotSupportedException();

    public override void SetLength(long value)
        => throw new NotSupportedException();

    // --------------------------------------------------------
    // Преобразование одного байта в стего-блок (10 эталонов)
    // --------------------------------------------------------
    private byte[] HideByte(byte value)
    {
        // Представляем байт как трёхзначное десятичное число: d2 d1 d0
        int v = value;
        int d2 = v / 100;        // сотни (0..2)
        int rem = v % 100;
        int d1 = rem / 10;       // десятки (0..9)
        int d0 = rem % 10;       // единицы (0..9)

        // Для каждой цифры скрываем её индекс соответствующим эталоном
        BitVector c2 = _stegoAlg.HideEtalon(d2);
        BitVector c1 = _stegoAlg.HideEtalon(d1);
        BitVector c0 = _stegoAlg.HideEtalon(d0);

        byte[] b2 = c2.ToByteArray();
        byte[] b1 = c1.ToByteArray();
        byte[] b0 = c0.ToByteArray();

        // Склеиваем 3 контейнера в один стего-блок
        byte[] result = new byte[b2.Length + b1.Length + b0.Length];

        int pos = 0;
        Buffer.BlockCopy(b2, 0, result, pos, b2.Length); pos += b2.Length;
        Buffer.BlockCopy(b1, 0, result, pos, b1.Length); pos += b1.Length;
        Buffer.BlockCopy(b0, 0, result, pos, b0.Length);

        return result;
    }

    // --------------------------------------------------------
    // Восстановление одного байта из стего-блока
    // --------------------------------------------------------
    public byte DiscloseByte(byte[] hidden)
    {
        if (hidden == null)
            throw new ArgumentNullException(nameof(hidden));

        if (hidden.Length != _hiddenByteLen)
            throw new ArgumentException("Неверная длина скрытого блока для 10 эталонов.", nameof(hidden));

        // Разделяем общий блок на три части по одному контейнеру
        byte[] b2 = new byte[_containerByteLen];
        byte[] b1 = new byte[_containerByteLen];
        byte[] b0 = new byte[_containerByteLen];

        int pos = 0;
        Buffer.BlockCopy(hidden, pos, b2, 0, _containerByteLen); pos += _containerByteLen;
        Buffer.BlockCopy(hidden, pos, b1, 0, _containerByteLen); pos += _containerByteLen;
        Buffer.BlockCopy(hidden, pos, b0, 0, _containerByteLen);

        // Восстанавливаем BitVector-ы
        BitVector c2 = new BitVector(b2, _stegoAlg.etalonLength);
        BitVector c1 = new BitVector(b1, _stegoAlg.etalonLength);
        BitVector c0 = new BitVector(b0, _stegoAlg.etalonLength);

        // Распознаём индексы эталонов
        int d2 = _stegoAlg.DiscloseEtalon(c2);
        int d1 = _stegoAlg.DiscloseEtalon(c1);
        int d0 = _stegoAlg.DiscloseEtalon(c0);

        if (d2 < 0 || d1 < 0 || d0 < 0)
            throw new InvalidOperationException("Не удалось распознать десятичную цифру.");

        int v = d2 * 100 + d1 * 10 + d0;
        if (v > 255)
            throw new InvalidOperationException("Ошибка: декодировано число > 255.");

        return (byte)v;
    }
}

// ============================================================
// Ассоциативное стего-кодирование на основе набора эталонов
// ============================================================
public class AssocStego
{
    public readonly BitVector[] etalons;
    public readonly int etalonLength;

    private readonly BitVector zeroVector;
    private readonly List<int>[] maskUnitPositions;
    private BitVector[] key;

    /// <summary>Список позиций единичных битов масок для каждого эталона.</summary>
    public IReadOnlyList<int>[] MaskUnitPositions => maskUnitPositions;

    /// <summary>Текущий ключ (массив масок), должен иметь ту же длину, что и массив эталонов.</summary>
    public BitVector[] Key
    {
        get => key ?? throw new InvalidOperationException("Ключ ещё не сгенерирован и не задан.");
        set
        {
            if (value is null)
                throw new ArgumentNullException(nameof(value));
            if (value.Length != etalons.Length)
                throw new ArgumentException("Длина ключа должна совпадать с количеством эталонов.", nameof(value));
            key = value;
        }
    }

    public AssocStego(params string[] e)
    {
        if (e is null || e.Length == 0)
            throw new ArgumentException("Не передано ни одного эталона.", nameof(e));

        etalonLength = e[0].Length;
        if (e.Any(s => s is null || s.Length != etalonLength))
            throw new ArgumentException("Все эталоны должны иметь одинаковую длину.");

        etalons = new BitVector[e.Length];
        maskUnitPositions = new List<int>[e.Length];

        for (int i = 0; i < e.Length; i++)
            maskUnitPositions[i] = new List<int>();

        // Нулевой вектор нужной длины (кратно 8 битам)
        zeroVector = new BitVector((etalonLength + 7) & ~7);

        for (int i = 0; i < e.Length; i++)
            etalons[i] = new BitVector(e[i]);
    }

    /// <summary>
    /// Генерация ключа (масок) для всех эталонов.
    /// </summary>
    public BitVector[] CreateKey()
    {
        var eIndexes = Enumerable.Range(0, etalons.Length).ToList();
        CreateKey(eIndexes);

        var masks = new BitVector[etalons.Length];
        for (int i = 0; i < etalons.Length; i++)
            masks[i] = CreateVector(etalonLength, maskUnitPositions[i].ToArray());

        Key = masks;
        return masks;
    }

    /// <summary>
    /// Рекурсивная генерация ключа по алгоритму дихотомического деления множества эталонов.
    /// </summary>
    public void CreateKey(List<int> eIndexes, bool firstStepPermutation = true, bool resetMaskUnitPositions = true)
    {
        if (resetMaskUnitPositions)
            ResetMaskUnitPositions();

        if (eIndexes is null)
            throw new ArgumentNullException(nameof(eIndexes));
        if (eIndexes.Count < 2)
            return;

        BitVector a_0 = new(etalonLength);
        BitVector a_1 = new(etalonLength);

        // Случайная перестановка исходного множества на начальном шаге.
        var c = firstStepPermutation ? CreateCryptoPermutation(eIndexes) : eIndexes;
        var d_1 = new List<int> { c[0] };

        a_0 = etalons[c[0]] ^ etalons[c[1]];

        // Формирование дихотомических подмножеств.
        for (int i = 0; i < c.Count - 2; i++)
        {
            a_1 = etalons[c[0]] ^ etalons[c[i + 2]];
            var a_3 = a_0 & a_1;
            if (a_3 == zeroVector)
                d_1.Add(c[i + 2]);
            else
                a_0 = a_3;
        }

        // Выбираем случайную позицию единичного бита в полученном векторе a_0.
        int randomOneBitIndex = GetRandomOneBitIndex(a_0);

        // Фиксируем её для всех эталонов в текущем множестве.
        foreach (var idx in c)
            maskUnitPositions[idx].Add(randomOneBitIndex);

        // Формируем разность множеств c - d_1.
        var d_2 = c.Except(d_1).ToList();

        // Рекурсивная обработка дихотомических множеств.
        Parallel.Invoke(
            () => CreateKey(d_1, true, false),
            () => CreateKey(d_2, true, false)
        );
    }

    /// <summary>Сохранить ключ в бинарный файл.</summary>
    public void SaveKeyToFile(string filePath, BitVector[] keyToSave)
    {
        if (keyToSave == null)
            throw new ArgumentNullException(nameof(keyToSave));

        if (keyToSave.Length != etalons.Length)
            throw new ArgumentException("Длина массива ключей не совпадает с числом эталонов.");

        using var fs = File.Create(filePath);
        using var bw = new BinaryWriter(fs);

        // Magic-число для формата (произвольное, но постоянное)
        const int MAGIC = 0x41534B59; // 'A','S','K','Y'

        bw.Write(MAGIC);
        bw.Write(keyToSave.Length);
        bw.Write(etalonLength);

        for (int i = 0; i < keyToSave.Length; i++)
        {
            byte[] bytes = keyToSave[i].ToByteArray();
            bw.Write(bytes.Length); // длина массива байт
            bw.Write(bytes);        // сами байты
        }
    }

    /// <summary>Загрузить ключ из файла и установить его как текущий.</summary>
    public BitVector[] LoadKeyFromFile(string filePath)
    {
        using var fs = File.OpenRead(filePath);
        using var br = new BinaryReader(fs);

        const int MAGIC = 0x41534B59;

        int magic = br.ReadInt32();
        if (magic != MAGIC)
            throw new InvalidDataException("Неверный формат файла ключа (magic).");

        int keyCount = br.ReadInt32();
        int bitLength = br.ReadInt32();

        if (bitLength != etalonLength)
            throw new InvalidDataException($"Длина битового вектора в файле ({bitLength}) не совпадает с etalonLength ({etalonLength}).");

        if (keyCount != etalons.Length)
            throw new InvalidDataException($"Количество ключей в файле ({keyCount}) не совпадает с количеством эталонов ({etalons.Length}).");

        var loadedKey = new BitVector[keyCount];

        for (int i = 0; i < keyCount; i++)
        {
            int len = br.ReadInt32();
            byte[] bytes = br.ReadBytes(len);
            if (bytes.Length != len)
                throw new EndOfStreamException("Файл ключа повреждён: не хватает данных.");

            loadedKey[i] = new BitVector(bytes, bitLength);
        }

        key = loadedKey;
        return loadedKey;
    }

    /// <summary>Проверка, что для каждого эталона сигнатура по маске уникальна.</summary>
    public void ValidateKeysOrThrow(BitVector[] key)
    {
        var map = new Dictionary<string, int>(StringComparer.Ordinal);

        for (int i = 0; i < etalons.Length; i++)
        {
            var sig = etalons[i] & key[i];
            string sigStr = sig.ToString();
            if (map.TryGetValue(sigStr, out int j))
                throw new InvalidOperationException($"Неоднозначные ключи: эталоны {j} и {i} имеют одинаковую подпись по своим маскам.");
            map[sigStr] = i;
        }
    }

    /// <summary>Распознать, какой эталон скрыт в данном стего-контейнере.</summary>
    public int DiscloseEtalon(BitVector stegoContainer)
    {
        for (int i = 0; i < etalons.Length; i++)
        {
            // Проверяем совпадение по маске
            if ((stegoContainer & key[i]) == (etalons[i] & key[i]))
                return i; // найден совпадающий эталон
        }
        return -1; // ничего не распознано
    }

    /// <summary>Скрыть индекс эталона в случайном контейнере с использованием соответствующей маски.</summary>
    public BitVector HideEtalon(int eIndex)
    {
        BitVector container = GenerateContainer(etalonLength);
        return container ^ ((container ^ etalons[eIndex]) & key[eIndex]);
    }

    /// <summary>Сгенерировать случайный контейнер нужной длины.</summary>
    public BitVector GenerateContainer(int bitLength)
    {
        int byteCount = (bitLength + 7) >> 3;
        byte[] randomBytes = new byte[byteCount];
        RandomNumberGenerator.Fill(randomBytes);
        return new BitVector(randomBytes, bitLength);
    }

    /// <summary>Вернуть случайный индекс единичного бита в векторе.</summary>
    int GetRandomOneBitIndex(BitVector v)
    {
        var ones = new List<int>();

        for (int i = 0; i < v.BitLength; i++)
            if (v.GetBit(i))
                ones.Add(i);

        return ones[RandomNumberGenerator.GetInt32(ones.Count)];
    }

    /// <summary>Перестановка Фишера–Йейтса с криптографическим выбором индексов.</summary>
    List<int> CreateCryptoPermutation(List<int> list)
    {
        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = RandomNumberGenerator.GetInt32(i + 1);
            (list[i], list[j]) = (list[j], list[i]);
        }
        return list;
    }

    /// <summary>Сброс накопленных позиций единичных битов масок.</summary>
    void ResetMaskUnitPositions()
    {
        foreach (var list in maskUnitPositions)
            list.Clear();
    }

    /// <summary>Создать BitVector заданной длины с единицами в указанных позициях.</summary>
    BitVector CreateVector(int bitLength, params int[] nonZeroIndexes)
    {
        int bufferLength = (bitLength + 7) >> 3;
        byte[] bitBuffer = new byte[bufferLength];

        foreach (var bitIndex in nonZeroIndexes)
        {
            if (bitIndex >= bitLength)
                throw new ArgumentOutOfRangeException(nameof(nonZeroIndexes), "Индекс бита выходит за пределы диапазона.");

            int byteIndex = bufferLength - 1 - (bitIndex >> 3);
            int bitOffset = bitIndex & 7;

            byte mask = (byte)(1 << bitOffset);

            bitBuffer[byteIndex] = (byte)(bitBuffer[byteIndex] & ~mask);
            bitBuffer[byteIndex] |= mask;
        }

        return new BitVector(bitBuffer, bitLength);
    }
}