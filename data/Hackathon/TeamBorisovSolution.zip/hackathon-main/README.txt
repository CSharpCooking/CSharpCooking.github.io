Для запуска проекта необходимо:
1. Разархивировать архив hackathon.zip;
2. Открыть файл решения hackathon.sln в Visual Studio;
3. Добавить файл in.txt в папку "hackathon\bin\Debug\net9.0\";
4. Построить и запустить проект.