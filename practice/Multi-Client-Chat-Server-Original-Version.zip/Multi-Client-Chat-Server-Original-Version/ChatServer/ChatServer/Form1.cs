using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace ChatServer
{
    public partial class Form1 : Form
    {
        private delegate void UpdateStatusCallback(string strMessage);
        private ChatServer mainServer;

        public Form1()
        {
            mainServer = new ChatServer();
            // On application exit
            Application.ApplicationExit += new EventHandler(OnApplicationExit);
            InitializeComponent();
        }

        private void btnListen_Click(object sender, EventArgs e)
        {
            mainServer.SetIpAddress(IPAddress.Parse(txtIp.Text));

            // Hook the StatusChanged event handler to mainServer_StatusChanged
            ChatServer.StatusChanged += new StatusChangedEventHandler(mainServer_StatusChanged);

            // Start listening for connections
            mainServer.StartListening();
            btnListen.Enabled = false;
            txtIp.Enabled = false;

            // Show that we started to listen for connections
            txtLog.AppendText("Monitoring for connections...\r\n");            
        }

        public void mainServer_StatusChanged(object sender, StatusChangedEventArgs e)
        {
            // Call the method that updates the form
            this.Invoke(new UpdateStatusCallback(this.UpdateStatus), new object[] { e.EventMessage });
        }

        private void UpdateStatus(string strMessage)
        {
            // Updates the log with the message
            txtLog.AppendText(strMessage + "\r\n");
        }

        // The event handler for application exit
        public void OnApplicationExit(object sender, EventArgs e)
        {
           mainServer.StopListener();
        }
    }
}