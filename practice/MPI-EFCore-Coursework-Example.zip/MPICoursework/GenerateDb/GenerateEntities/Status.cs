﻿namespace MPICoursework.GenerateDb.GenerateEntities
{
    public class Status
    {
        // Id заполняется вручную
        public int Id { get; set; }
        // Название статуса
        public string StatusName {  get; set; }
    }
}
