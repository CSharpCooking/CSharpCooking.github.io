using System;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace ChatClient
{
    public partial class Form1 : Form
    {
        StreamWriter swSender;
        StreamReader srReceiver;
        TcpClient tcpServer;
        Thread thrMessaging;
        bool connected;
        public Form1()
        {
            Application.ApplicationExit += new EventHandler(OnApplicationExit);
            InitializeComponent();
        }
        void OnApplicationExit(object sender, EventArgs e)
        {
            if (connected == true)
            {
                connected = false;
                swSender.Close();
                srReceiver.Close();
            }
        }

        void BtnConnectClick(object sender, EventArgs e)
        {
            if (connected == false)
            {
                InitializeConnection();
            }
            else
            {
                CloseConnection("Disconnected at user's request.");
            }
        }
        void InitializeConnection()
        {
            try
            {
                tcpServer = new TcpClient();
                tcpServer.Connect(IPAddress.Parse(txtIp.Text), ushort.Parse(txtPort.Text));
                connected = true;
                txtIp.Enabled = false;
                txtPort.Enabled = false;
                txtUser.Enabled = false;
                txtMessage.Enabled = true;
                btnSend.Enabled = true;
                btnConnect.Text = "Disconnect";
                swSender = new StreamWriter(tcpServer.GetStream()) { AutoFlush = true };
                swSender.WriteLine(txtUser.Text);
                thrMessaging = new Thread(ReceiveMessages);
                thrMessaging.Start();
            }
            catch (Exception exc)
            {
                UpdateLog("Error: " + exc.Message);
            }
        }

        void ReceiveMessages()
        {
            try
            {
                srReceiver = new StreamReader(tcpServer.GetStream());
                string ConResponse = srReceiver.ReadLine();
                if (ConResponse[0] == '1')
                {
                    Invoke(new Action<string>(UpdateLog), "Connected successfully!");
                }
                else
                {
                    string Reason = "Not connected: ";
                    Reason += ConResponse.Substring(2, ConResponse.Length - 2);
                    Invoke(new Action<string>(CloseConnection), Reason);
                    return;
                }
                while (connected)
                {
                    string s = srReceiver.ReadLine();
                    if (s == "Administrator: Server is stopped.")
                        Invoke(new Action<string>(CloseConnection), s);
                    else
                        Invoke(new Action<string>(UpdateLog), s);
                }
            }
            catch
            {
                Invoke(new Action<string>(CloseConnection), "The connection to the server is complete.");
            }
        }
        void UpdateLog(string message)
        {
            txtLog.AppendText(message + "\r\n");
        }
        void CloseConnection(string reason)
        {
            txtIp.Enabled = true;
            txtPort.Enabled = true;
            txtUser.Enabled = true;
            txtMessage.Enabled = false;
            btnSend.Enabled = false;
            btnConnect.Text = "Connect";
            connected = false;
            swSender.Close();
            srReceiver.Close();
            txtLog.AppendText(reason + "\r\n");
        }
        void SendMessage()
        {
            try
            {
                if (txtMessage.Text.Length > 0)
                {
                    swSender.WriteLine(txtMessage.Text);
                    txtMessage.Text = "";
                }
            }
            catch (Exception exc)
            {
                CloseConnection($"Error: {exc.Message}");
            }
        }
        void BtnSendClick(object sender, EventArgs e)
        {
            SendMessage();
        }
        void MessageKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
                SendMessage();
        }
    }
}