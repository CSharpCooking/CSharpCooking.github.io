using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Collections.Concurrent;
using System.Text;
using System.Collections.Generic;

namespace ChatServer
{
    class StatusChangedEventArgs : EventArgs
    {
        public readonly string eventMessage;
        public StatusChangedEventArgs(string strEventMsg)
        {
            eventMessage = strEventMsg;
        }
    }
    delegate void StatusChangedEventHandler(object sender, StatusChangedEventArgs e);
    class ConnectionException : Exception
    {
        public ConnectionException(string message)
            : base(message) { }
    }
    class ChatServer
    {
        readonly ConcurrentDictionary<string, TcpClient> htUsers = new ConcurrentDictionary<string, TcpClient>();
        IPEndPoint endPoint;
        public event StatusChangedEventHandler StatusChanged;
        bool servRunning;
        public ChatServer()
        {
            servRunning = false;
        }
        public void SetIPEndPoint(string ip, string p)
        {
            endPoint = new IPEndPoint(IPAddress.Parse(ip), int.Parse(p));
        }
        Thread thrListener;
        public void StopListener()
        {
            if (servRunning == true)
            {
                SendAdminMessage("Server is stopped.");
                servRunning = false;
                tlsClient.Stop();
            }
        }
        TcpListener tlsClient;
        public bool AddUser(TcpClient tcpUser, string strUsername)
        {
            htUsers.TryAdd(strUsername, tcpUser);
            SendAdminMessage(strUsername + " has joined us");
            return true;
        }
        public void RemoveUser(string userName)
        {
            if (htUsers.TryRemove(userName, out TcpClient tcpUser))
            {
                tcpUser.Close();
                SendAdminMessage(userName + " has left us");
            }
        }
        public void OnStatusChanged(StatusChangedEventArgs e)
        {
            //� ������������� ��������� ����� ��������� � ������� �������
            //���������� ����������� ��������� ���������� �� ���������
            //������, ��������� � ������������� �������:
            //var temp = StatusChanged;
            //if (temp != null) temp(this, e);
            //������� � ������ C# 6, �� �� ����� ���������������� ����� ��������
            //��� ���������� temp � ������� null - �������� ��������:
            //StatusChanged?.Invoke(this, �);
            //������ ���������� � ������� � ����������, ������ ��� ���������
            //������������ ������ ������ �������.
            StatusChanged?.Invoke(null, e);
        }
        public void SendAdminMessage(string message)
        {
            StreamWriter sw;
            OnStatusChanged(new StatusChangedEventArgs("Administrator: " + message));
            foreach (KeyValuePair<string, TcpClient> kv in htUsers)
            {
                try
                {
                    using (sw = new StreamWriter(kv.Value.GetStream(), new UTF8Encoding(false, true), 0x400, true))
                    {
                        sw.WriteLine("Administrator: " + message);
                    }
                }
                catch
                {
                    RemoveUser(kv.Key);
                }
            }
        }
        public void SendMessage(string from, string message)
        {
            OnStatusChanged(new StatusChangedEventArgs(from + " says: " + message));
            foreach (KeyValuePair<string, TcpClient> kv in htUsers)
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(kv.Value.GetStream(), new UTF8Encoding(false, true), 0x400, true))
                    {
                        sw.WriteLine(from + " says: " + message);
                    }
                }
                catch
                {
                    RemoveUser(kv.Key);
                }
            }
        }
        public void StartListening()
        {
            tlsClient = new TcpListener(endPoint);
            tlsClient.Start();
            servRunning = true;
            thrListener = new Thread(KeepListening);
            thrListener.Start();
        }
        void KeepListening()
        {
            while (servRunning == true)
            {
                try
                {
                    var thr = new Thread(AcceptClient);
                    thr.Start(tlsClient.AcceptTcpClient());
                }
                catch { OnStatusChanged(new StatusChangedEventArgs("Administrator: Listening is stopped.")); }
            }
        }
        void AcceptClient(object tc)
        {
            TcpClient tcpClient = (TcpClient)tc;
            bool userConn = false;
            string currUser = null;
            StreamReader srReceiver = null;
            StreamWriter swSender = null;
            try
            {
                srReceiver = new StreamReader(tcpClient.GetStream());
                swSender = new StreamWriter(tcpClient.GetStream()) { AutoFlush = true };
                currUser = srReceiver.ReadLine();
                if (htUsers.ContainsKey(currUser) == true)
                {
                    swSender.WriteLine("0|The username already exists.");
                    throw new ConnectionException("The username already exists.");
                }
                if (htUsers.Count == 30)
                {
                    swSender.WriteLine("0|Connection limit exhausted.");
                    throw new ConnectionException("Connection limit exhausted.");
                }
                if (currUser == "Administrator")
                {
                    swSender.WriteLine("0|The username is reserved.");
                    throw new ConnectionException("The username is reserved.");
                }
                if (currUser == "")
                {
                    swSender.WriteLine("0|A name must contain at least 1 character.");
                    throw new ConnectionException("A name must contain at least 1 character.");
                }
                swSender.WriteLine("1");
                userConn = AddUser(tcpClient, currUser);
                string s;
                while ((s = srReceiver.ReadLine()) != null)
                {
                    SendMessage(currUser, s);
                }
            }
            catch (ConnectionException exc)
            {
                OnStatusChanged(new StatusChangedEventArgs($"Unsuccessful connection: {exc.Message}"));
            }
            finally
            {
                swSender.Close();
                srReceiver.Close();
                if (userConn) RemoveUser(currUser);
            }
        }
    }
}
