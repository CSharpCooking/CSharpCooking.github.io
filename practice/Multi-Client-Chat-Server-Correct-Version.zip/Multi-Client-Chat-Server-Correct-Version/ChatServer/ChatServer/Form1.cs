using System;
using System.Windows.Forms;

namespace ChatServer
{
	public partial class Form1 : Form
	{
		readonly ChatServer mainServer;
		public Form1()
		{
			mainServer = new ChatServer();
			Application.ApplicationExit += new EventHandler(OnApplicationExit);
			InitializeComponent();
		}
		void BtnListenClick(object sender, EventArgs e)
		{
			if (txtIP.Enabled)
			{
				mainServer.StatusChanged += new StatusChangedEventHandler(MainServerStatusChanged);
				mainServer.SetIPEndPoint(txtIP.Text, txtPort.Text);
				mainServer.StartListening();
				txtIP.Enabled = false;
				txtPort.Enabled = false;
				btnListen.Text = "Stop Listening";
				txtLog.AppendText("Monitoring is started.\r\n");
			}
			else
				mainServer.StopListener();
		}
		void MainServerStatusChanged(object sender, StatusChangedEventArgs e)
		{
			Invoke(new Action<string>(UpdateStatus), e.eventMessage);
		}
		void UpdateStatus(string message)
		{
			txtLog.AppendText(message + "\r\n");
			if (message == "Administrator: Listening is stopped.")
			{
				txtIP.Enabled = true;
				txtPort.Enabled = true;
				btnListen.Text = "Start Listening";
				txtLog.AppendText("Monitoring is stopped.\r\n");
				mainServer.StatusChanged -= new StatusChangedEventHandler(MainServerStatusChanged);
			}
		}
		void OnApplicationExit(object sender, EventArgs e)
		{
			mainServer.StopListener();
		}
	}
}