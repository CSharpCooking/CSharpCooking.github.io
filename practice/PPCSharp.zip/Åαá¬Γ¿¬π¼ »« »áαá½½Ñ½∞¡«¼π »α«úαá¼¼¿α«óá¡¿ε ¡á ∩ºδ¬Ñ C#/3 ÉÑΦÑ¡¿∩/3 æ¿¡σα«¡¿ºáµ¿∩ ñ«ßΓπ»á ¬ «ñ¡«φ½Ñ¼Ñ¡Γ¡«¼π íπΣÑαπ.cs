﻿// См. https://youtu.be/tLQkfXMW6M4

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Linq;

namespace SoloLearn
{
    class Program
    {
        static void Main()
        {
            List<string> ReaderBuf = new List<string>();
            string buffer = null;
            bool finish = false;

            Thread[] reader = new Thread[10];
            for (int k = 0; k < reader.Length; k++)
                reader[k] = new Thread(() =>
                {
                    while (!finish || buffer != null)
                    {
                        if (buffer != null)
                        {
                            string old_value = Interlocked.Exchange(ref buffer, null);
                            if (old_value != null) ReaderBuf.Add(old_value);
                        }
                    }
                });

            Thread[] writer = new Thread[10];
            for (int k = 0; k < writer.Length; k++)
            {
                int k_copy = k;
                writer[k] = new Thread(() =>
                {
                    string[] WriterBuf = { "Message A from thread #" + k_copy, "Message B from thread #" + k_copy, "Message C from thread #" + k_copy };
                    for (int i = 0; i < WriterBuf.Length;)
                        if (Interlocked.CompareExchange(ref buffer, WriterBuf[i], null) == null) i++;
                });
            }

            foreach (Thread w in writer) w.Start();
            foreach (Thread r in reader) r.Start();

            foreach (Thread w in writer) w.Join();
            finish = true;
            foreach (Thread r in reader) r.Join();

            foreach (string str in ReaderBuf.OrderBy(r => r))
                Console.WriteLine(str);
        }
    }
}