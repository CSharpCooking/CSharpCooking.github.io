﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Работа_с_потоками
{
    class Program
    {
        const int I = 1000_000_000;
        const double c = 5.7;
        static double[] mass = new double[N];
        const int N = 12;
        const int M = 3;
        static void Print(double[] m)
        {
            foreach (double iter in m)
                Console.WriteLine(iter);
        }
        static void Work(object o)
        {
            int ThreadNumber = (int)o;
            int part = N / M;
            for (int i = ThreadNumber * part; i < (ThreadNumber + 1) * part; i++)
            {
                double mass_i = 0;
                for (int j = 0; j < I; j++)
                    mass_i = j * c;
                mass[i] = mass_i;
            }
        }
        static void Main(string[] args)
        {
            // инициализация массива
            for (int i = 0; i < N; i++)
                mass[i] = i * 7;

            // Последовательная обработка обработка
            {
                // начало отсчёта времени
                Stopwatch time = new Stopwatch();
                time.Start();
                // последовательная обработка
                for (int i = 0; i < N; i++)
                {
                    double mass_i = 0;
                    for (int j = 0; j < I; j++)
                        mass_i = j * c;
                    mass[i] = mass_i;
                }
                time.Stop();
                //Print(mass);
                Console.WriteLine("Total time последовательной обработки : {0} ms.", time.Elapsed.TotalMilliseconds);
            }

            // Параллельная обработка 
            {
                Stopwatch time = new Stopwatch();
                time.Start();
                Thread[] threads = new Thread[M];
                for (int i = 0; i < M; i++)
                {
                    threads[i] = new Thread(Work);
                    threads[i].Start(i);
                }
                for (int i = 0; i < M; i++)
                    threads[i].Join();
                time.Stop();
                //Print(mass);
                Console.WriteLine("Total time параллельной обработки: {0} ms.", time.Elapsed.TotalMilliseconds);
            }
        }
    }
}