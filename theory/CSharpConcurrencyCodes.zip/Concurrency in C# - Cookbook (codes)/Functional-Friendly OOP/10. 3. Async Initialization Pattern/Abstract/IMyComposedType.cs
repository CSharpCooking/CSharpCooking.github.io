﻿namespace AsyncInitializationPattern.Abstract
{
    internal interface IMyComposedType
    {
    }
}